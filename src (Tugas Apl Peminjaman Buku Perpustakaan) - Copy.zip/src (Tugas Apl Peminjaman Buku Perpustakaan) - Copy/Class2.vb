﻿Imports MySql.Data.MySqlClient

Module Koneksi

    Public conn As MySqlConnection

    Public Sub KoneksiDB()
        Try
            conn = New MySqlConnection("server=localhost;user id=root;password=;database=db_perpustakaan")
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As Exception
            MessageBox.Show("Koneksi Gagal: " & ex.Message)
        End Try
    End Sub

End Module
