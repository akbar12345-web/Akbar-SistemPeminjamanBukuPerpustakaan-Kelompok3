﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMenuUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblJudul = New Label()
        lblNama = New Label()
        lblTglPinjam = New Label()
        lblKodeBuku = New Label()
        lblNamaBuku = New Label()
        lblJK = New Label()
        lblKelas = New Label()
        lblAlamat = New Label()
        lblNIM = New Label()
        lblTglKembali = New Label()
        txtAlamat = New TextBox()
        txtNIM = New TextBox()
        txtNama = New TextBox()
        txtNamaBuku = New TextBox()
        txtKodeBuku = New TextBox()
        dtpPinjam = New DateTimePicker()
        dtpKembali = New DateTimePicker()
        btnSave = New Button()
        btnLihat = New Button()
        btnHapus = New Button()
        cmbJK = New ComboBox()
        dgvData = New DataGridView()
        Panel1 = New Panel()
        txtKelas = New TextBox()
        btnExit = New Button()
        PictureBox1 = New PictureBox()
        CType(dgvData, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblJudul
        ' 
        lblJudul.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        lblJudul.AutoSize = True
        lblJudul.Font = New Font("Segoe UI", 22F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblJudul.Location = New Point(236, 23)
        lblJudul.Name = "lblJudul"
        lblJudul.Size = New Size(684, 120)
        lblJudul.TabIndex = 0
        lblJudul.Text = "Peminjaman Buku Perpustakan " & vbCrLf & "Universitas Pelita Bangsa"
        lblJudul.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblNama
        ' 
        lblNama.AutoSize = True
        lblNama.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNama.Location = New Point(48, 176)
        lblNama.Name = "lblNama"
        lblNama.Size = New Size(88, 28)
        lblNama.TabIndex = 1
        lblNama.Text = "Nama ="
        ' 
        ' lblTglPinjam
        ' 
        lblTglPinjam.AutoSize = True
        lblTglPinjam.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblTglPinjam.Location = New Point(557, 316)
        lblTglPinjam.Name = "lblTglPinjam"
        lblTglPinjam.Size = New Size(182, 28)
        lblTglPinjam.TabIndex = 2
        lblTglPinjam.Text = "Tgl Peminjaman ="
        ' 
        ' lblKodeBuku
        ' 
        lblKodeBuku.AutoSize = True
        lblKodeBuku.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblKodeBuku.Location = New Point(557, 271)
        lblKodeBuku.Name = "lblKodeBuku"
        lblKodeBuku.Size = New Size(134, 28)
        lblKodeBuku.TabIndex = 3
        lblKodeBuku.Text = "Kode Buku ="
        ' 
        ' lblNamaBuku
        ' 
        lblNamaBuku.AutoSize = True
        lblNamaBuku.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNamaBuku.Location = New Point(557, 227)
        lblNamaBuku.Name = "lblNamaBuku"
        lblNamaBuku.Size = New Size(142, 28)
        lblNamaBuku.TabIndex = 4
        lblNamaBuku.Text = "Nama Buku ="
        ' 
        ' lblJK
        ' 
        lblJK.AutoSize = True
        lblJK.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblJK.Location = New Point(48, 361)
        lblJK.Name = "lblJK"
        lblJK.Size = New Size(162, 28)
        lblJK.TabIndex = 5
        lblJK.Text = "Jenis Kelamin ="
        ' 
        ' lblKelas
        ' 
        lblKelas.AutoSize = True
        lblKelas.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblKelas.Location = New Point(48, 316)
        lblKelas.Name = "lblKelas"
        lblKelas.Size = New Size(82, 28)
        lblKelas.TabIndex = 6
        lblKelas.Text = "Kelas ="
        ' 
        ' lblAlamat
        ' 
        lblAlamat.AutoSize = True
        lblAlamat.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblAlamat.Location = New Point(48, 271)
        lblAlamat.Name = "lblAlamat"
        lblAlamat.Size = New Size(100, 28)
        lblAlamat.TabIndex = 7
        lblAlamat.Text = "Alamat ="
        ' 
        ' lblNIM
        ' 
        lblNIM.AutoSize = True
        lblNIM.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNIM.Location = New Point(48, 227)
        lblNIM.Name = "lblNIM"
        lblNIM.Size = New Size(73, 28)
        lblNIM.TabIndex = 8
        lblNIM.Text = "NIM ="
        ' 
        ' lblTglKembali
        ' 
        lblTglKembali.AutoSize = True
        lblTglKembali.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblTglKembali.Location = New Point(557, 361)
        lblTglKembali.Name = "lblTglKembali"
        lblTglKembali.Size = New Size(199, 28)
        lblTglKembali.TabIndex = 9
        lblTglKembali.Text = "Tgl Pengembalian ="
        ' 
        ' txtAlamat
        ' 
        txtAlamat.Location = New Point(236, 271)
        txtAlamat.Name = "txtAlamat"
        txtAlamat.Size = New Size(267, 31)
        txtAlamat.TabIndex = 11
        ' 
        ' txtNIM
        ' 
        txtNIM.Location = New Point(236, 224)
        txtNIM.Name = "txtNIM"
        txtNIM.Size = New Size(267, 31)
        txtNIM.TabIndex = 12
        ' 
        ' txtNama
        ' 
        txtNama.Location = New Point(236, 173)
        txtNama.Name = "txtNama"
        txtNama.Size = New Size(267, 31)
        txtNama.TabIndex = 13
        ' 
        ' txtNamaBuku
        ' 
        txtNamaBuku.Location = New Point(765, 224)
        txtNamaBuku.Name = "txtNamaBuku"
        txtNamaBuku.Size = New Size(290, 31)
        txtNamaBuku.TabIndex = 14
        ' 
        ' txtKodeBuku
        ' 
        txtKodeBuku.Location = New Point(765, 268)
        txtKodeBuku.Name = "txtKodeBuku"
        txtKodeBuku.Size = New Size(290, 31)
        txtKodeBuku.TabIndex = 15
        ' 
        ' dtpPinjam
        ' 
        dtpPinjam.Location = New Point(765, 314)
        dtpPinjam.Name = "dtpPinjam"
        dtpPinjam.Size = New Size(290, 31)
        dtpPinjam.TabIndex = 16
        ' 
        ' dtpKembali
        ' 
        dtpKembali.Location = New Point(765, 359)
        dtpKembali.Name = "dtpKembali"
        dtpKembali.Size = New Size(290, 31)
        dtpKembali.TabIndex = 17
        ' 
        ' btnSave
        ' 
        btnSave.Location = New Point(84, 411)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(162, 54)
        btnSave.TabIndex = 18
        btnSave.Text = "Save"
        btnSave.UseVisualStyleBackColor = True
        ' 
        ' btnLihat
        ' 
        btnLihat.Location = New Point(341, 411)
        btnLihat.Name = "btnLihat"
        btnLihat.Size = New Size(162, 54)
        btnLihat.TabIndex = 19
        btnLihat.Text = "Lihat"
        btnLihat.UseVisualStyleBackColor = True
        ' 
        ' btnHapus
        ' 
        btnHapus.Location = New Point(609, 411)
        btnHapus.Name = "btnHapus"
        btnHapus.Size = New Size(162, 54)
        btnHapus.TabIndex = 20
        btnHapus.Text = "Hapus"
        btnHapus.UseVisualStyleBackColor = True
        ' 
        ' cmbJK
        ' 
        cmbJK.FormattingEnabled = True
        cmbJK.Location = New Point(236, 361)
        cmbJK.Name = "cmbJK"
        cmbJK.Size = New Size(267, 33)
        cmbJK.TabIndex = 21
        ' 
        ' dgvData
        ' 
        dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvData.Location = New Point(38, 483)
        dgvData.Name = "dgvData"
        dgvData.RowHeadersWidth = 62
        dgvData.Size = New Size(1017, 514)
        dgvData.TabIndex = 22
        ' 
        ' Panel1
        ' 
        Panel1.Location = New Point(38, 1003)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1017, 50)
        Panel1.TabIndex = 24
        ' 
        ' txtKelas
        ' 
        txtKelas.Location = New Point(236, 313)
        txtKelas.Name = "txtKelas"
        txtKelas.Size = New Size(267, 31)
        txtKelas.TabIndex = 25
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(870, 411)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(162, 54)
        btnExit.TabIndex = 26
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ActiveCaption
        PictureBox1.Image = My.Resources.Resources.logo_upb
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(148, 131)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 27
        PictureBox1.TabStop = False
        ' 
        ' FormMenuUtama
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(1093, 1050)
        Controls.Add(PictureBox1)
        Controls.Add(btnExit)
        Controls.Add(txtKelas)
        Controls.Add(Panel1)
        Controls.Add(dgvData)
        Controls.Add(cmbJK)
        Controls.Add(btnHapus)
        Controls.Add(btnLihat)
        Controls.Add(btnSave)
        Controls.Add(dtpKembali)
        Controls.Add(dtpPinjam)
        Controls.Add(txtKodeBuku)
        Controls.Add(txtNamaBuku)
        Controls.Add(txtNama)
        Controls.Add(txtNIM)
        Controls.Add(txtAlamat)
        Controls.Add(lblTglKembali)
        Controls.Add(lblNIM)
        Controls.Add(lblAlamat)
        Controls.Add(lblKelas)
        Controls.Add(lblJK)
        Controls.Add(lblNamaBuku)
        Controls.Add(lblKodeBuku)
        Controls.Add(lblTglPinjam)
        Controls.Add(lblNama)
        Controls.Add(lblJudul)
        Name = "FormMenuUtama"
        Text = "FormMenuUtama"
        CType(dgvData, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblJudul As Label
    Friend WithEvents lblNama As Label
    Friend WithEvents lblTglPinjam As Label
    Friend WithEvents lblKodeBuku As Label
    Friend WithEvents lblNamaBuku As Label
    Friend WithEvents lblJK As Label
    Friend WithEvents lblKelas As Label
    Friend WithEvents lblAlamat As Label
    Friend WithEvents lblNIM As Label
    Friend WithEvents lblTglKembali As Label
    Friend WithEvents txtAlamat As TextBox
    Friend WithEvents txtNIM As TextBox
    Friend WithEvents txtNama As TextBox
    Friend WithEvents txtNamaBuku As TextBox
    Friend WithEvents txtKodeBuku As TextBox
    Friend WithEvents dtpPinjam As DateTimePicker
    Friend WithEvents dtpKembali As DateTimePicker
    Friend WithEvents btnSave As Button
    Friend WithEvents btnLihat As Button
    Friend WithEvents btnHapus As Button
    Friend WithEvents cmbJK As ComboBox
    Friend WithEvents dgvData As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtKelas As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
