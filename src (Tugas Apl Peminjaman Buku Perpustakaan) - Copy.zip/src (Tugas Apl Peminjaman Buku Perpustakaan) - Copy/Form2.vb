﻿Imports MySql.Data.MySqlClient

Public Class FormMenuUtama
    Private cmd As MySqlCommand

    Private Sub BersihkanInput()
        txtNama.Clear()
        txtNIM.Clear()
        txtAlamat.Clear()
        txtKelas.Clear()
        cmbJK.SelectedIndex = -1
        txtNamaBuku.Clear()
        txtKodeBuku.Clear()
        dtpPinjam.Value = DateTime.Now
        dtpKembali.Value = DateTime.Now
    End Sub


    Private Sub FormMenuUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Koneksi()

        dgvData.ColumnCount = 9
        dgvData.Columns(0).Name = "Nama"
        dgvData.Columns(1).Name = "NIM"
        dgvData.Columns(2).Name = "Alamat"
        dgvData.Columns(3).Name = "Kelas"
        dgvData.Columns(4).Name = "Jenis Kelamin"
        dgvData.Columns(5).Name = "Nama Buku"
        dgvData.Columns(6).Name = "Kode Buku"
        dgvData.Columns(7).Name = "Tgl Peminjaman"
        dgvData.Columns(8).Name = "Tgl Pengembalian"

        cmbJK.Items.Add("Laki-Laki")
        cmbJK.Items.Add("Perempuan")
    End Sub

    Private Sub Koneksi()
        Throw New NotImplementedException()
    End Sub



    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        If dgvData.SelectedRows.Count > 0 Then
            For Each row As DataGridViewRow In dgvData.SelectedRows
                dgvData.Rows.Remove(row)
            Next
            MessageBox.Show("Data berhasil dihapus!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Pilih baris yang ingin dihapus!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub


    Private Sub btnLihat_Click(sender As Object, e As EventArgs) Handles btnLihat.Click
        If dgvData.Rows.Count = 0 Then
            MessageBox.Show("Belum ada data untuk ditampilkan!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim formLihat As New FormLihat


        Dim lastRow = dgvData.Rows(dgvData.Rows.Count - 2)
        formLihat.lblNama.Text = lastRow.Cells(0).Value.ToString
        formLihat.lblNIM.Text = lastRow.Cells(1).Value.ToString
        formLihat.lblAlamat.Text = lastRow.Cells(2).Value.ToString
        formLihat.lblKelas.Text = lastRow.Cells(3).Value.ToString
        formLihat.lblJK.Text = lastRow.Cells(4).Value.ToString
        formLihat.lblNamaBuku.Text = lastRow.Cells(5).Value.ToString
        formLihat.lblKodeBuku.Text = lastRow.Cells(6).Value.ToString
        formLihat.lblTglPinjam.Text = lastRow.Cells(7).Value.ToString
        formLihat.lblTglKembali.Text = lastRow.Cells(8).Value.ToString

        formLihat.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Dim konfirmasi As DialogResult
        konfirmasi = MessageBox.Show("Apakah Anda yakin ingin keluar dari aplikasi?", "Konfirmasi Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If konfirmasi = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub cmbJK_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbJK.SelectedIndexChanged

    End Sub

    Private Sub btnCetak_Click(sender As Object, e As EventArgs)
        If txtNama.Text = "" Or txtNIM.Text = "" Or txtAlamat.Text = "" Or txtKelas.Text = "" Or
       cmbJK.Text = "" Or txtNamaBuku.Text = "" Or txtKodeBuku.Text = "" Then
            MessageBox.Show("Isi semua data terlebih dahulu!")
            Exit Sub
        End If

        Koneksi()


        Dim sql = "INSERT INTO peminjaman 
        (nama, nim, alamat, kelas, jenis_kelamin, nama_buku, kode_buku, tgl_pinjam, tgl_kembali)
        VALUES
        (@nama, @nim, @alamat, @kelas, @jk, @nb, @kb, @tp, @tk)"

        cmd = New MySqlCommand
        cmd.Parameters.AddWithValue("@nama", txtNama.Text)
        cmd.Parameters.AddWithValue("@nim", txtNIM.Text)
        cmd.Parameters.AddWithValue("@alamat", txtAlamat.Text)
        cmd.Parameters.AddWithValue("@kelas", txtKelas.Text)
        cmd.Parameters.AddWithValue("@jk", cmbJK.Text)
        cmd.Parameters.AddWithValue("@nb", txtNamaBuku.Text)
        cmd.Parameters.AddWithValue("@kb", txtKodeBuku.Text)
        cmd.Parameters.AddWithValue("@tp", dtpPinjam.Value)
        cmd.Parameters.AddWithValue("@tk", dtpKembali.Value)

        cmd.ExecuteNonQuery()
        MessageBox.Show("Data berhasil disimpan ke database!")

        BersihkanInput()
    End Sub
End Class

