﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnLogin = New Button()
        Label1 = New Label()
        Username = New Label()
        Paswword = New Label()
        txtPassword = New TextBox()
        txtUsername = New TextBox()
        SuspendLayout()
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = SystemColors.Highlight
        btnLogin.Font = New Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogin.Location = New Point(531, 445)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(186, 65)
        btnLogin.TabIndex = 0
        btnLogin.Text = "LOGIN"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.ButtonHighlight
        Label1.Font = New Font("Times New Roman", 22F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ImageAlign = ContentAlignment.MiddleRight
        Label1.Location = New Point(113, 66)
        Label1.Name = "Label1"
        Label1.Size = New Size(828, 102)
        Label1.TabIndex = 1
        Label1.Text = "SELAMAT DATANG DIPERPUSTAKAN " & vbCrLf & "UNIVERSITAS PELITA BANGSA"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Username
        ' 
        Username.AutoSize = True
        Username.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Username.Location = New Point(256, 246)
        Username.Name = "Username"
        Username.Size = New Size(227, 32)
        Username.TabIndex = 2
        Username.Text = "Username / NIM ="
        ' 
        ' Paswword
        ' 
        Paswword.AutoSize = True
        Paswword.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Paswword.Location = New Point(256, 325)
        Paswword.Name = "Paswword"
        Paswword.Size = New Size(146, 32)
        Paswword.TabIndex = 3
        Paswword.Text = "Password ="
        ' 
        ' txtPassword
        ' 
        txtPassword.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        txtPassword.Location = New Point(531, 325)
        txtPassword.Name = "txtPassword"
        txtPassword.PasswordChar = "*"c
        txtPassword.Size = New Size(245, 34)
        txtPassword.TabIndex = 4
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        txtUsername.Location = New Point(531, 244)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(245, 34)
        txtUsername.TabIndex = 5
        ' 
        ' FormLogin
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        BackgroundImage = My.Resources.Resources.WhatsApp_Image_2025_10_31_at_21_27_08
        ClientSize = New Size(1045, 623)
        Controls.Add(txtUsername)
        Controls.Add(txtPassword)
        Controls.Add(Paswword)
        Controls.Add(Username)
        Controls.Add(Label1)
        Controls.Add(btnLogin)
        Name = "FormLogin"
        Text = "Form Login"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnLogin As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Username As Label
    Friend WithEvents Paswword As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox

End Class
