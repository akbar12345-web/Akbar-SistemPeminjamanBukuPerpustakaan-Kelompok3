﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormLihat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormLihat))
        lblNama = New Label()
        lblNIM = New Label()
        lblAlamat = New Label()
        lblKelas = New Label()
        lblJK = New Label()
        lblTglKembali = New Label()
        lblTglPinjam = New Label()
        lblNamaBuku = New Label()
        lblKodeBuku = New Label()
        lblJudul = New Label()
        btnTutup = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        RichTextBox1 = New RichTextBox()
        Label5 = New Label()
        Label6 = New Label()
        SuspendLayout()
        ' 
        ' lblNama
        ' 
        lblNama.AutoSize = True
        lblNama.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNama.Location = New Point(209, 131)
        lblNama.Name = "lblNama"
        lblNama.Size = New Size(74, 28)
        lblNama.TabIndex = 0
        lblNama.Text = "Label1"
        ' 
        ' lblNIM
        ' 
        lblNIM.AutoSize = True
        lblNIM.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNIM.Location = New Point(209, 191)
        lblNIM.Name = "lblNIM"
        lblNIM.Size = New Size(74, 28)
        lblNIM.TabIndex = 1
        lblNIM.Text = "Label2"
        ' 
        ' lblAlamat
        ' 
        lblAlamat.AutoSize = True
        lblAlamat.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblAlamat.Location = New Point(209, 245)
        lblAlamat.Name = "lblAlamat"
        lblAlamat.Size = New Size(74, 28)
        lblAlamat.TabIndex = 2
        lblAlamat.Text = "Label1"
        ' 
        ' lblKelas
        ' 
        lblKelas.AutoSize = True
        lblKelas.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblKelas.Location = New Point(209, 300)
        lblKelas.Name = "lblKelas"
        lblKelas.Size = New Size(74, 28)
        lblKelas.TabIndex = 3
        lblKelas.Text = "Label2"
        ' 
        ' lblJK
        ' 
        lblJK.AutoSize = True
        lblJK.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblJK.Location = New Point(209, 353)
        lblJK.Name = "lblJK"
        lblJK.Size = New Size(74, 28)
        lblJK.TabIndex = 4
        lblJK.Text = "Label3"
        ' 
        ' lblTglKembali
        ' 
        lblTglKembali.AutoSize = True
        lblTglKembali.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblTglKembali.Location = New Point(209, 557)
        lblTglKembali.Name = "lblTglKembali"
        lblTglKembali.Size = New Size(74, 28)
        lblTglKembali.TabIndex = 5
        lblTglKembali.Text = "Label4"
        ' 
        ' lblTglPinjam
        ' 
        lblTglPinjam.AutoSize = True
        lblTglPinjam.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblTglPinjam.Location = New Point(209, 513)
        lblTglPinjam.Name = "lblTglPinjam"
        lblTglPinjam.Size = New Size(74, 28)
        lblTglPinjam.TabIndex = 6
        lblTglPinjam.Text = "Label5"
        ' 
        ' lblNamaBuku
        ' 
        lblNamaBuku.AutoSize = True
        lblNamaBuku.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblNamaBuku.Location = New Point(209, 463)
        lblNamaBuku.Name = "lblNamaBuku"
        lblNamaBuku.Size = New Size(74, 28)
        lblNamaBuku.TabIndex = 7
        lblNamaBuku.Text = "Label6"
        ' 
        ' lblKodeBuku
        ' 
        lblKodeBuku.AutoSize = True
        lblKodeBuku.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblKodeBuku.Location = New Point(209, 406)
        lblKodeBuku.Name = "lblKodeBuku"
        lblKodeBuku.Size = New Size(74, 28)
        lblKodeBuku.TabIndex = 8
        lblKodeBuku.Text = "Label7"
        ' 
        ' lblJudul
        ' 
        lblJudul.AutoSize = True
        lblJudul.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblJudul.Location = New Point(243, -1)
        lblJudul.Name = "lblJudul"
        lblJudul.Size = New Size(587, 45)
        lblJudul.TabIndex = 9
        lblJudul.Text = "Perpustakan Universitas Pelita Bangsa"
        ' 
        ' btnTutup
        ' 
        btnTutup.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnTutup.Location = New Point(420, 676)
        btnTutup.Name = "btnTutup"
        btnTutup.Size = New Size(123, 58)
        btnTutup.TabIndex = 10
        btnTutup.Text = "Close"
        btnTutup.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label1.Location = New Point(12, 131)
        Label1.Name = "Label1"
        Label1.Size = New Size(88, 28)
        Label1.TabIndex = 11
        Label1.Text = "Nama ="
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label2.Location = New Point(12, 189)
        Label2.Name = "Label2"
        Label2.Size = New Size(79, 28)
        Label2.TabIndex = 12
        Label2.Text = "NIM = "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label3.Location = New Point(12, 243)
        Label3.Name = "Label3"
        Label3.Size = New Size(100, 28)
        Label3.TabIndex = 13
        Label3.Text = "Alamat ="
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label4.Location = New Point(12, 353)
        Label4.Name = "Label4"
        Label4.Size = New Size(162, 28)
        Label4.TabIndex = 14
        Label4.Text = "Jenis Kelamin ="
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label7.Location = New Point(12, 406)
        Label7.Name = "Label7"
        Label7.Size = New Size(142, 28)
        Label7.TabIndex = 15
        Label7.Text = "Nama Buku ="
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label8.Location = New Point(12, 463)
        Label8.Name = "Label8"
        Label8.Size = New Size(134, 28)
        Label8.TabIndex = 16
        Label8.Text = "Kode Buku ="
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label9.Location = New Point(12, 298)
        Label9.Name = "Label9"
        Label9.Size = New Size(82, 28)
        Label9.TabIndex = 17
        Label9.Text = "Kelas ="
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label10.Location = New Point(12, 513)
        Label10.Name = "Label10"
        Label10.Size = New Size(182, 28)
        Label10.TabIndex = 18
        Label10.Text = "Tgl Peminjaman ="
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label11.Location = New Point(12, 557)
        Label11.Name = "Label11"
        Label11.Size = New Size(199, 28)
        Label11.TabIndex = 19
        Label11.Text = "Tgl Pengembalian ="
        ' 
        ' RichTextBox1
        ' 
        RichTextBox1.Font = New Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RichTextBox1.Location = New Point(420, 56)
        RichTextBox1.Name = "RichTextBox1"
        RichTextBox1.Size = New Size(677, 580)
        RichTextBox1.TabIndex = 21
        RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(12, 56)
        Label5.Name = "Label5"
        Label5.Size = New Size(218, 38)
        Label5.TabIndex = 22
        Label5.Text = "Data Peminjam"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = SystemColors.HighlightText
        Label6.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(12, 634)
        Label6.Name = "Label6"
        Label6.Size = New Size(372, 100)
        Label6.TabIndex = 23
        Label6.Text = "Perpustakaan Universitas Pelita Bangsa" & vbCrLf & "Jl. Inspeksi Kalimalang, Bekasi, Jawa Barat" & vbCrLf & "Email: perpustakaan@pelitabangsa.ac.id" & vbCrLf & "Telepon: (021) 8899-1234"
        ' 
        ' FormLihat
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(1109, 774)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(RichTextBox1)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnTutup)
        Controls.Add(lblJudul)
        Controls.Add(lblKodeBuku)
        Controls.Add(lblNamaBuku)
        Controls.Add(lblTglPinjam)
        Controls.Add(lblTglKembali)
        Controls.Add(lblJK)
        Controls.Add(lblKelas)
        Controls.Add(lblAlamat)
        Controls.Add(lblNIM)
        Controls.Add(lblNama)
        Name = "FormLihat"
        Text = "Liat Data Peminjam"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNama As Label
    Friend WithEvents lblNIM As Label
    Friend WithEvents lblAlamat As Label
    Friend WithEvents lblKelas As Label
    Friend WithEvents lblJK As Label
    Friend WithEvents lblTglKembali As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblKodeBuku As Label
    Friend WithEvents lblJudul As Label
    Friend WithEvents lblTglPinjam As Label
    Friend WithEvents lblNamaBuku As Label
    Friend WithEvents btnTutup As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label5 As Label
End Class
