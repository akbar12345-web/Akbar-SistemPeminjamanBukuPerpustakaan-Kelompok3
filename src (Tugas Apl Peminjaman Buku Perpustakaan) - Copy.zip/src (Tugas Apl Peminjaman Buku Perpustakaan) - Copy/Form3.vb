﻿Public Class FormLihat
    Private Sub btnTutup_Click(sender As Object, e As EventArgs) Handles btnTutup.Click
        Me.Close()
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub FormLihat_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
