﻿Imports MySql.Data.MySqlClient
Imports System.Data

Public Class DatabaseHelper
    Private Shared ReadOnly connectionString As String =
        "Server=localhost;" &
        "Database=pemrog_desktop_v1_db;" &
        "User Id=root;" &
        "Password=rootpassword;" &
        "Port=3306;"

    Public Shared Function GetConnection() As MySqlConnection
        Try
            Dim connection As New MySqlConnection(connectionString)
            Return connection
        Catch ex As Exception
            Throw New Exception("Error membuat koneksi database: " & ex.Message)
        End Try
    End Function

    Public Shared Function OpenConnection(connection As MySqlConnection) As Boolean
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            Return True
        Catch ex As MySqlException
            Throw New Exception("Error membuka koneksi database: " & ex.Message)
        End Try
    End Function

    Public Shared Sub CloseConnection(connection As MySqlConnection)
        Try
            If connection IsNot Nothing AndAlso connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        Catch ex As Exception
            Throw New Exception("Error menutup koneksi database: " & ex.Message)
        End Try
    End Sub

    Public Shared Function GetAllProducts() As DataTable
        Dim connection As MySqlConnection = Nothing
        Dim command As MySqlCommand = Nothing
        Dim adapter As MySqlDataAdapter = Nothing
        Dim dataTable As New DataTable()

        Try
            connection = GetConnection()
            OpenConnection(connection)

            Dim query As String = "SELECT id, nama, deskripsi, created_at FROM products ORDER BY created_at DESC"
            command = New MySqlCommand(query, connection)

            adapter = New MySqlDataAdapter(command)
            adapter.Fill(dataTable)

            Return dataTable
        Catch ex As Exception
            Throw New Exception("Error mengambil daftar user: " & ex.Message)
        Finally
            If adapter IsNot Nothing Then
                adapter.Dispose()
            End If
            If command IsNot Nothing Then
                command.Dispose()
            End If
            If connection IsNot Nothing Then
                CloseConnection(connection)
                connection.Dispose()
            End If
        End Try
    End Function

    Public Shared Function TestConnection() As Boolean
        Dim connection As MySqlConnection = Nothing
        Try
            connection = GetConnection()
            OpenConnection(connection)
            Return True
        Catch ex As Exception
            Return False
        Finally
            If connection IsNot Nothing Then
                CloseConnection(connection)
                connection.Dispose()
            End If
        End Try
    End Function

    Public Shared Function InsertProduct(nama As String, deskripsi As String, tanggal As Date) As Boolean
        Dim connection As MySqlConnection = Nothing
        Dim command As MySqlCommand = Nothing

        Debug.Print("This is a log message in VBA.")
        Debug.Print("Current time: " & Now())
        Debug.Print("nama", nama, deskripsi, tanggal)

        Try
            connection = GetConnection()
            OpenConnection(connection)

            Dim query As String = "INSERT INTO products (nama, deskripsi, created_at) VALUES (@nama, @deskripsi, @tanggal)"
            command = New MySqlCommand(query, connection)
            command.Parameters.AddWithValue("@nama", nama)
            command.Parameters.AddWithValue("@deskripsi", deskripsi)
            command.Parameters.AddWithValue("@tanggal", tanggal)
            command.Prepare()

            Dim rowsAffected As Integer = command.ExecuteNonQuery()
            Return rowsAffected > 0

        Catch ex As MySqlException
            Debug.Print("MySQL Error Number: ", ex.Number)
            Debug.Print("MySQL Error Message: ", ex.Message)

            Debug.Print("A database error occurred: ", ex)
            Throw New Exception("Error menambahkan products: ")

        Catch ex As Exception
            Throw New Exception("Error menambahkan products: " & ex.Message)
        Finally
            If command IsNot Nothing Then
                command.Dispose()
            End If
            If connection IsNot Nothing Then
                CloseConnection(connection)
                connection.Dispose()
            End If
        End Try
    End Function
End Class